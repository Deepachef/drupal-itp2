$(document).ready(function () {
   alert();
});;
