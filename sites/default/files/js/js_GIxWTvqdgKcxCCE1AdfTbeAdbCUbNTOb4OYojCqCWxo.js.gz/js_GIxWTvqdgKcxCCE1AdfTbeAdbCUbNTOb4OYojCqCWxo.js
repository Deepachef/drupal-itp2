(function ($, Drupal) {
   Drupal.behaviors.backend = {
      attach: function (context, settings) {
    console.log('abc');

      }
   };

}(jQuery, Drupal));;
