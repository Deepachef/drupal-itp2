(function ($, Drupal, drupalSettings) {
   Drupal.behaviors.backend = {
      attach: function (context, settings) {
    console.log('abc');

      }
   };

}(jQuery, Drupal, drupalSettings));;
