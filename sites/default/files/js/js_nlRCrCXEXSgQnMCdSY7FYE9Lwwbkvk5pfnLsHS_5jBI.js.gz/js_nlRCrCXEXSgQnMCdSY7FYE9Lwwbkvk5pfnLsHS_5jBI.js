(function ($, Drupal) {
   Drupal.behaviors.backend = {
      attach: function (context, settings) {
 alert('abc');
      }
   };

}(jQuery, Drupal));;
