(function ($, Drupal) {
   Drupal.behaviors.myModuleBehavior = {
      attach: function (context, settings) {

         alert();
      }
   }
});;
